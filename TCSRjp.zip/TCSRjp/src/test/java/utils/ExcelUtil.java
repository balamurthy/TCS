
package utils;
//sample commit
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
 
public class ExcelUtil
{
    public FileInputStream fis = null;
    public static XSSFWorkbook workbook = null;
    public static XSSFSheet sheet = null;
    public XSSFRow row = null;
    public XSSFCell cell = null;
 
    public ExcelUtil(String xlFilePath) throws Exception
    {
        fis = new FileInputStream(xlFilePath);
        workbook = new XSSFWorkbook(fis);
        fis.close();
    }
    	
    
    public static Object[][] getExcelData(String sheetName) {

        Object[][] data = null;

        try {
            
        	FileInputStream fis = new FileInputStream(
                System.getProperty("user.dir")
                + "/src/test/resources/xlFile.xlsx"
            );
        	workbook = new XSSFWorkbook(fis);
            
        	sheet = workbook.getSheet(sheetName);
            
         
            int rows = sheet.getPhysicalNumberOfRows();
            int cols = sheet.getRow(0).getPhysicalNumberOfCells();

            data = new Object[rows - 1][cols];

            for (int i = 1; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    data[i - 1][j] =
                        sheet.getRow(i).getCell(j).toString();
                }
            }
            workbook.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
    
 // returns number of  rows in a sheet
    public int getRowCount(String sheetName)
    {
     int index = workbook.getSheetIndex(sheetName);
     if(index==-1)
      return 0;
     else
     {
     sheet = workbook.getSheetAt(index);
     int number=sheet.getLastRowNum()+1;
     return number;
     }
    
    }
    public int getColumnCount(String sheetName)
    {
     // check if sheet exists
     if(!isSheetExist(sheetName))
      return -1;
    
     sheet = workbook.getSheet(sheetName);
     row = sheet.getRow(0);
    
     if(row==null)
      return -1;
    
     return row.getLastCellNum();
    }
           // find whether sheets exists
    public boolean isSheetExist(String sheetName)
    {
     int index = workbook.getSheetIndex(sheetName);
     if(index==-1){
      index=workbook.getSheetIndex(sheetName.toUpperCase());
       if(index==-1)
        return false;
       else
        return true;
     }
     else
      return true;
    }
       
    public String getCellData(String sheetName,int colNum,int rowNum)
    {
        try
        {
            sheet = workbook.getSheet(sheetName);
            row = sheet.getRow(rowNum);
            cell = row.getCell(colNum);
            if(cell.getCellTypeEnum() == CellType.STRING)
                return cell.getStringCellValue();
            else if(cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA)
            {
                String cellValue  = String.valueOf(cell.getNumericCellValue());
                if (HSSFDateUtil.isCellDateFormatted(cell))
                {
                    DateFormat df = new SimpleDateFormat("dd/MM/yy");
                    Date date = cell.getDateCellValue();
                    cellValue = df.format(date);
                }
                return cellValue;
            }else if(cell.getCellTypeEnum() == CellType.BLANK)
                return "";
            else
                return String.valueOf(cell.getBooleanCellValue());
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "row "+rowNum+" or column "+colNum +" does not exist  in Excel";
        }
    }
}
